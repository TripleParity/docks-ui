import { Injectable } from '@angular/core';

@Injectable()
export class AuthService {

  constructor() { }
  // TODO(CDuPlooy): Once the backend is ready add token acquisition here and save to TokenStorage.
}
