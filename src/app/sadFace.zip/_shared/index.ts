// Barrel

export { NavbarComponent } from './navbar/navbar.component';
export { TaskListViewComponent } from './task-list-view/task-list-view.component';
